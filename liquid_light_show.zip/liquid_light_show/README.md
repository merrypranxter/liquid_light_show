# liquid_light_show

A creative coding project exploring **1960s oil-projector psychedelia** — colored oil and water and dye between hot clockglasses on an overhead projector, projected through as immiscible fluids boil, blob, and swirl. Wet, organic, breathing color. A full fluid solver. The big one.

## What Is This?

A **generator** that simulates a real fluid solver (Stam stable-fluids) with phase separation (Cahn-Hilliard), thermal convection (Rayleigh-Bénard), and thin-film iridescence. The result is the look of a 1960s liquid light show: oil and water projected through, the colors breathing and merging and splitting, the light wet and alive.

**Bonus:** Can project a `u_source` image through the simulated liquid medium.

## Project Structure

```
src/
  js/
    main.js           — WebGL setup, render loop, parameter UI
    fbo-pingpong.js   — velocity / dye / phase fields
    solver.js         — Stam stable-fluids step order
    color-maps.js     — palette ramps
  shaders/
    engines/          — swappable medium models
      stable-fluids.glsl    — advect + diffuse + project
      phase-separation.glsl — Cahn-Hilliard immiscibility (the "oil")
      thermal-convection.glsl — buoyancy plumes (Rayleigh-Bénard)
      thin-film-color.glsl  — thickness → iridescent spectrum
    advect.frag       — semi-Lagrangian advection
    pressure.frag     — Jacobi pressure-project
    dye.frag          — density advect + heat injection
    projection.frag   — backlit additive color + soft defocus
```

## Running

Open `index.html` in any modern browser. WebGL2 required. This is the gnarliest build of the batch — a full fluid solver with pressure projection.

## Current Medium Engines

- [ ] _stable_fluids — Stam solver: advect → diffuse → pressure-project → advect dye
- [ ] _phase_separation — Cahn-Hilliard keeps oil & water as distinct blobby domains
- [ ] _thermal_convection — Rayleigh-Bénard buoyancy plumes
- [ ] _thin_film_color — film thickness → spectral iridescence (dichroic sheen)

## Aesthetic Regimes

- [ ] fillmore_1967 — slow churn, magenta/cyan/orange, big lazy blobs, heavy bloom
- [ ] boiling_acid — high heat, fast convection, splitting cells, electric palette
- [ ] oil_slick — thin-film dominant, dichroic rainbow sheen on near-black
- [ ] ink_in_water — pure dye diffusion plumes, no heat, elegant

## Parameters

- `viscosity` — 0.0–0.1 (fluid thickness)
- `heat_buoyancy` — 0.0–2.0 (thermal plume strength)
- `surface_tension` — 0.0–1.0 (phase separation)
- `dye_injection` — 0.0–1.0 (color injection rate)
- `film_thickness_scale` — 0–1000 nm (thin-film color range)
- `defocus` — 0.0–1.0 (projected light softness)

## Ecosystem Hooks

Consumes `thin_film_iridescence` + `structural_color` (color logic). Shares fluid engine with `fluid_dynamics`, `klein-fluid-sim`, `ferrofluid_dance`. Pairs with `psychedelic_collage`, `vintage_blacklight_poster_style`, `shoegaze_style`. Huge synergy.

---

*The light is wet. The color is alive. The oil remembers the heat.*
