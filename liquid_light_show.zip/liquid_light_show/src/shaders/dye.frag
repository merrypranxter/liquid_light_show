// TODO: dye.frag
