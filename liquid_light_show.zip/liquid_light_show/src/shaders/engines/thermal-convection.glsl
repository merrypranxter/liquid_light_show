// TODO: engines/thermal-convection.glsl
