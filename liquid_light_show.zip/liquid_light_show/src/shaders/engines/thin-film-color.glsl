// TODO: engines/thin-film-color.glsl
