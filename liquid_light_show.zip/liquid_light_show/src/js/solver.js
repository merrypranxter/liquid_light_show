// liquid_light_show — solver.js
// Stam stable-fluids step order.
